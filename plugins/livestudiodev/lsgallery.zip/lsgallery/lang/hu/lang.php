<?php return [
    'plugin' => [
        'name' => 'LSGallery',
        'description' => ''
    ]
];