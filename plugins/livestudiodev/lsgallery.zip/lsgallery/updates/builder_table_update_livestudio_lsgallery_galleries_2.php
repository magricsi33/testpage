<?php namespace Livestudio\Lsgallery\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateLivestudioLsgalleryGalleries2 extends Migration
{
    public function up()
    {
        Schema::table('livestudio_lsgallery_galleries', function($table)
        {
            $table->dropColumn('images');
        });
    }
    
    public function down()
    {
        Schema::table('livestudio_lsgallery_galleries', function($table)
        {
            $table->text('images')->nullable();
        });
    }
}
