<?php namespace Livestudio\Lsgallery\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateLivestudioLsgalleryAlbums extends Migration
{
    public function up()
    {
        Schema::create('livestudio_lsgallery_albums', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id')->unsigned();
            $table->string('name')->nullable();
            $table->text('description')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('livestudio_lsgallery_albums');
    }
}
