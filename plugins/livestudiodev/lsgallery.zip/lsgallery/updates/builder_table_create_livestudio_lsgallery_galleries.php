<?php namespace Livestudio\Lsgallery\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateLivestudioLsgalleryGalleries extends Migration
{
    public function up()
    {
        Schema::create('livestudio_lsgallery_galleries', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id')->unsigned();
            $table->integer('album_id');
            $table->string('name');
            $table->string('description');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('livestudio_lsgallery_galleries');
    }
}
