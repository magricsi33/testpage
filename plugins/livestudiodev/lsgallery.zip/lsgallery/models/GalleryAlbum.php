<?php namespace LivestudioDev\Lsgallery\Models;

use Model;

/**
 * Model
 */
class GalleryAlbum extends Model
{
    use \October\Rain\Database\Traits\Validation;
    

    /**
     * @var string The database table used by the model.
     */
    public $table = 'livestudio_lsgallery_albums';

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    public $hasMany = [
        'galleries' => 'LivestudioDev\Lsgallery\Models\Gallery'
    ];

    public $attachOne = [
        'image' => 'System\Models\File'
    ];
}
