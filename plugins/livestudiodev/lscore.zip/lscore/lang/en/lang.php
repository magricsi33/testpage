<?php return [
    'plugin' => [
        'name' => 'LSCore',
        'description' => ''
    ]
];